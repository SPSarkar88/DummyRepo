﻿namespace StringSpliterService
{
    public class StringSpliter
    {
        public StringSpliter()
        {
            
        }
        /// <summary>
        /// Split the input string by space
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string[] SplitString(string input)
        {
            return input.Trim().Split(' ');
        }
        /// <summary>
        /// Split the input string by comma
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string[] SplitStringByComma(string input)
        {
            return input.Trim().Split(',');
        }
        /// <summary>
        /// Split the input string by pipe
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string[] SplitStringByPipe(string input)
        {
            return input.Trim().Split('|');
        }
    }
}
