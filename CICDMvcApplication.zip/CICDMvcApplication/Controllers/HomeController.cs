using System.Diagnostics;
using CICDMvcApplication.Models;
using Microsoft.AspNetCore.Mvc;
using StringSpliterService;

namespace CICDMvcApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult StringSplit()
        {
            return View();
        }
        [HttpPost]
        public IActionResult StringSplit(StringData stringData)
        {
            if(ModelState.IsValid)
            {
                var splitStringService = new StringSpliter();
                var splitData = Enumerable.Empty<string>();
                splitData = ProcessStringData(stringData, splitStringService, splitData);
                if (splitData is not null && splitData != Enumerable.Empty<string>())
                {
                    return View("StringSplitResult", splitData);  
                }
            }
            return View();
        }

        /// <summary>
        /// Process the string data based on the delimeter
        /// </summary>
        /// <param name="stringData"></param>
        /// <param name="splitStringService"></param>
        /// <param name="splitData"></param>
        /// <returns></returns>
        private IEnumerable<string> ProcessStringData(StringData stringData, StringSpliter splitStringService, IEnumerable<string> splitData)
        {
            if (IsStringContainsComma(stringData.Data))
            {
                string joinString = GetCleanData(stringData, splitStringService);
                splitData = splitStringService
                    .SplitStringByComma(joinString);
            }
            else if (IsStringContainsPipe(stringData.Data))
            {
                string joinString = GetCleanData(stringData, splitStringService);
                splitData = splitStringService
                    .SplitStringByPipe(joinString);
            }
            else if (IsStringContainsSpace(stringData.Data))
            {
                splitData = splitStringService
                    .SplitString(stringData.Data);
            }
            

            return splitData.AsEnumerable();
        }

        /// <summary>
        /// Get the clean data
        /// </summary>
        /// <param name="stringData"></param>
        /// <param name="splitStringService"></param>
        /// <returns></returns>
        private string GetCleanData(StringData stringData, StringSpliter splitStringService)
        {
            var rawData = splitStringService.SplitString(stringData.Data.Trim());
            var joinString = string.Empty;
            if (rawData.Any())
            {
                var cleanedRawData = rawData.Select(x => x.Trim());
                joinString = string.Join("", cleanedRawData);
            }

            return joinString;
        }

        /// <summary>
        /// Check if the string contains comma
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool IsStringContainsComma(string data)
        {
            return data.Contains(",");
        }
        /// <summary>
        /// Check if the string contains space
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool IsStringContainsSpace(string data)
        {
            return data.Contains(" ");
        }
        /// <summary>
        /// Check if the string contains pipe
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool IsStringContainsPipe(string data)
        {
            return data.Contains("|");
        }
    }
}
