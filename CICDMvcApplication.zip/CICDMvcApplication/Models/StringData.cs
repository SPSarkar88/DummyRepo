﻿namespace CICDMvcApplication.Models
{
    public class StringData
    {
        public string Data { get; set; }
    }
}
